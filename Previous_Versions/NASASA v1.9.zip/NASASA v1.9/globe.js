/* globe.js — MW.globe: Mars as a turning globe on the start screen, and the dive into it when the app opens.
 *
 * The globe is drawn by WebGL from the app's own terrain pack (terrain-data.js: MGS MOLA heights, the whole planet
 * every 0.25°), so every feature on it is real and in its place: Olympus Mons and the Tharsis volcanoes, Valles
 * Marineris, the Hellas and Argyre basins, the smooth northern lowlands. Colour follows height (low ground darker
 * and redder, high ground paler), relief is shaded from the north-west and exaggerated so it shows at this scale,
 * and the polar caps are painted where they lie. It is a relief map, not a photograph: Mars' light and dark
 * markings (dust, dark sand) are not in this data. Around the place the dive aims for, a second, finer texture is
 * made from the same pack (which is four times finer at Gale), so the last moments of the dive are less blurred.
 *
 *   MW.globe.start(canvas, place)   start drawing; place(w, h) gives the centre and radius in CSS px. Resolves true
 *                                   once the globe shows, false if this browser cannot draw it (no WebGL, no terrain)
 *   MW.globe.focus(lat, lon)        make the fine texture round this place (the dive target)
 *   MW.globe.dive(lat, lon, ms)     turn that place to the front, move the globe to the middle of the screen and fly
 *                                   down to it; returns a Promise that settles at the surface
 *   MW.globe.stop()                 stop drawing and free the GPU memory
 */
(function () {
  'use strict';
  var DEG = Math.PI / 180;
  var gl = null, cv = null, prog = null, U = {}, texMain = null, texFine = null, raf = 0, placeFn = null, alive = false;
  var view = { lat: 18, lon: 70, dist: 3.2, cx: 0, cy: 0, r: 0, fine: [0, 0, 0] };   // fine: lat, lon, half-size (deg) of the fine texture
  var SPIN = 4;                                                       // degrees of longitude a second: one turn in 90 s
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var dive = null, last = 0;

  /* ---------------------------------------------------------------- the textures, from the terrain pack */
  var STOPS = [[-8200, 52, 24, 17], [-5500, 88, 40, 26], [-3800, 122, 56, 33], [-2000, 150, 72, 40], [0, 176, 92, 52], [1800, 192, 110, 66],
               [3500, 204, 128, 84], [6000, 212, 146, 104], [11000, 222, 170, 132], [21500, 240, 222, 200]];
  function ramp(h) {
    if (h <= STOPS[0][0]) return STOPS[0].slice(1);
    for (var i = 1; i < STOPS.length; i++) if (h <= STOPS[i][0]) {
      var a = STOPS[i - 1], b = STOPS[i], t = (h - a[0]) / (b[0] - a[0]);
      return [a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t, a[3] + (b[3] - a[3]) * t];
    }
    return STOPS[STOPS.length - 1].slice(1);
  }
  function smooth(e0, e1, x) { var t = Math.max(0, Math.min(1, (x - e0) / (e1 - e0))); return t * t * (3 - 2 * t); }
  /* heights on a lat/lon window, then colour + hillshade into RGBA */
  function paint(W, H, lat0, lon0, dLat, dLon, exag) {
    var T = MW.terrain, z = new Float32Array(W * H), i, j;
    for (j = 0; j < H; j++) { var la = lat0 - (j + 0.5) * dLat; for (i = 0; i < W; i++) z[j * W + i] = T.heightAt(la, lon0 + (i + 0.5) * dLon) || 0; }
    var px = new Uint8Array(W * H * 4), M = 3389500 * DEG, sx = -0.62, sy = 0.62, sz = 0.48, sn = Math.hypot(sx, sy, sz);
    sx /= sn; sy /= sn; sz /= sn;                                     // sun from the north-west, 30° up
    for (j = 0; j < H; j++) {
      var lat = lat0 - (j + 0.5) * dLat, dx = Math.max(0.05, Math.cos(lat * DEG)) * dLon * M, dy = dLat * M;
      var cap = lat > 0 ? smooth(78.5, 83, lat) : smooth(-82.5, -85.5, lat);
      for (i = 0; i < W; i++) {
        var k = j * W + i, xl = i > 0 ? k - 1 : k + W - 1, xr = i < W - 1 ? k + 1 : k - W + 1, yu = j > 0 ? k - W : k, yd = j < H - 1 ? k + W : k;
        var gx = (z[xr] - z[xl]) / (2 * dx) * exag, gy = (z[yu] - z[yd]) / (2 * dy) * exag;
        var shade = (-gx * sx + gy * sy + sz) / Math.sqrt(gx * gx + gy * gy + 1);    // normal (-gx, gy, 1): east is +x, north is +y
        shade = 0.55 + 0.75 * Math.max(0, shade);
        var c = ramp(z[k]), w = cap * (0.75 + 0.25 * smooth(-6000, 2000, z[k]));
        var o = k * 4;
        px[o] = Math.min(255, (c[0] * (1 - w) + 238 * w) * shade);
        px[o + 1] = Math.min(255, (c[1] * (1 - w) + 232 * w) * shade);
        px[o + 2] = Math.min(255, (c[2] * (1 - w) + 226 * w) * shade);
        px[o + 3] = 255;
      }
    }
    return px;
  }
  function upload(tex, W, H, px) {
    gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, W, H, 0, gl.RGBA, gl.UNSIGNED_BYTE, px);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  }

  /* ---------------------------------------------------------------- the shader: a ray to a unit sphere, per pixel */
  var VS = 'attribute vec2 a;void main(){gl_Position=vec4(a,0.,1.);}';
  var FS = [
    'precision highp float;',
    'uniform vec2 C;uniform float R,D,tl,ln,lt,lightK;uniform vec3 fine;uniform sampler2D tm,tf;',
    'const float PI=3.14159265;',
    'void main(){',
    ' float th=tan(asin(1./3.2));',                                // a fixed lens: at the resting distance the edge is R px out;
    ' vec2 p=(gl_FragCoord.xy-C)/R*th;',                            // closer in (D smaller), the globe fills more of the screen
    ' vec3 o=vec3(0.,0.,D),d=normalize(vec3(p,-1.));',
    ' float b=dot(o,d),c=dot(o,o)-1.,h=b*b-c;',
    ' vec3 L=normalize(vec3(-.55,.42,.72));',
    ' float closest=length(o-d*b);',
    ' vec4 col=vec4(0.);',
    ' if(h>0.){',
    '  vec3 n=normalize(o+d*(-b-sqrt(h)));',
    '  float cs=cos(tl),sn=sin(tl);',
    '  vec3 q=vec3(n.x,n.y*cs+n.z*sn,-n.y*sn+n.z*cs);',                // un-tilt: the front of the globe is at latitude tl
    '  float lat=asin(clamp(q.y,-1.,1.)),lon=ln+atan(q.x,q.z);',
    '  float u=fract((lon/PI+1.)*.5),v=(.5-lat/PI);',
    '  vec3 base=texture2D(tm,vec2(u,v)).rgb;',
    '  float dl=lat/PI*180.-fine.x,dn=mod(lon/PI*180.-fine.y+540.,360.)-180.;',
    '  if(fine.z>0.&&abs(dl)<fine.z&&abs(dn)<fine.z){',
    '   vec3 f=texture2D(tf,vec2(dn/(2.*fine.z)+.5,.5-dl/(2.*fine.z))).rgb;',
    '   float e=1.-smoothstep(.75,1.,max(abs(dl),abs(dn))/fine.z);',
    '   base=mix(base,f,e);',
    '  }',
    '  float di=dot(n,L),lit=mix(1.,smoothstep(-.12,.55,di),lightK);',
    '  float rim=pow(1.-max(dot(n,-d),0.),3.);',
    '  vec3 rgb=base*(.05+.95*lit)+vec3(1.,.55,.35)*rim*.35*lit;',
    '  col=vec4(rgb,1.);',
    ' }',
    ' if(h<=0.){',                                                   // the thin dusty haze just beyond the edge
    '  float g=1.-smoothstep(1.,1.075,closest);',
    '  float a2=g*g*.55*mix(1.,clamp(dot(normalize(o-d*b),L)*.8+.45,0.,1.),lightK);',
    '  col=vec4(vec3(1.,.56,.36),a2);',
    ' }',
    ' gl_FragColor=col;',
    '}'].join('\n');
  function shader(type, src) { var s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s)); return s; }

  function size() {
    var dpr = Math.min(window.devicePixelRatio || 1, 1.5), w = cv.clientWidth, h = cv.clientHeight;
    if (cv.width !== Math.round(w * dpr) || cv.height !== Math.round(h * dpr)) { cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr); }
    return { w: w, h: h, dpr: dpr };
  }
  function ease(t) { return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; }
  function draw(ts) {
    if (!alive) return;
    raf = requestAnimationFrame(draw);
    var dt = last ? Math.min(0.1, (ts - last) / 1000) : 0; last = ts;
    var s = size(), at = placeFn(s.w, s.h), cx = at.x, cy = at.y, r = at.r, k = 1;
    if (dive) {
      var t = Math.min(1, (ts - dive.t0) / dive.ms), e = ease(t);
      view.lat = dive.lat0 + (dive.lat - dive.lat0) * ease(Math.min(1, t * 1.6));
      view.lon = dive.lon0 + dive.dLon * ease(Math.min(1, t * 1.6));
      var m = ease(Math.min(1, t * 1.8));                              // the globe moves to the middle first, then the camera falls
      cx = at.x + (s.w / 2 - at.x) * m; cy = at.y + (s.h / 2 - at.y) * m; r = at.r + (Math.min(s.w, s.h) * 0.36 - at.r) * m;
      view.dist = 1 + (dive.d0 - 1) * Math.pow(0.035, e);             // down to about 260 km up: Gale crater fills a third of the screen
      if (t >= 1 && !dive.done) { dive.done = true; dive.resolve(); }
    } else if (!reduce) view.lon = (view.lon + SPIN * dt) % 360;
    else view.dist = 3.2;
    gl.viewport(0, 0, cv.width, cv.height); gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT);
    gl.uniform2f(U.C, cx * s.dpr, (s.h - cy) * s.dpr); gl.uniform1f(U.R, r * s.dpr); gl.uniform1f(U.D, view.dist);
    gl.uniform1f(U.tl, view.lat * DEG); gl.uniform1f(U.ln, view.lon * DEG); gl.uniform1f(U.lightK, k);
    gl.uniform3f(U.fine, view.fine[0], view.fine[1], view.fine[2]);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
  }

  function start(canvas, place) {
    cv = canvas; placeFn = place;
    try { gl = cv.getContext('webgl', { premultipliedAlpha: false, alpha: true, antialias: false }) || cv.getContext('experimental-webgl'); } catch (e) { gl = null; }
    if (!gl || !MW.terrain) return Promise.resolve(false);
    return MW.terrain.load().then(function () {
      prog = gl.createProgram(); gl.attachShader(prog, shader(gl.VERTEX_SHADER, VS)); gl.attachShader(prog, shader(gl.FRAGMENT_SHADER, FS)); gl.linkProgram(prog);
      if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(prog));
      gl.useProgram(prog);
      var buf = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, buf); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
      var a = gl.getAttribLocation(prog, 'a'); gl.enableVertexAttribArray(a); gl.vertexAttribPointer(a, 2, gl.FLOAT, false, 0, 0);
      ['C', 'R', 'D', 'tl', 'ln', 'lightK', 'fine', 'tm', 'tf'].forEach(function (n) { U[n] = gl.getUniformLocation(prog, n); });
      gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
      texMain = gl.createTexture(); texFine = gl.createTexture();
      upload(texMain, 1440, 720, paint(1440, 720, 90, -180, 0.25, 0.25, 22));      // the pack's own spacing: one pixel per data point
      upload(texFine, 4, 4, new Uint8Array(64));
      gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, texMain); gl.uniform1i(U.tm, 0);
      gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, texFine); gl.uniform1i(U.tf, 1);
      alive = true; raf = requestAnimationFrame(draw);
      return true;
    }).catch(function (e) { if (window.console) console.warn('Globe not drawn: ' + e.message); return false; });
  }
  function focus(lat, lon) {
    if (!gl || !alive) return;
    var half = 4, n = 512;                                            // 8° square, about 470 km: Gale crater and its rim
    gl.activeTexture(gl.TEXTURE1); upload(texFine, n, n, paint(n, n, lat + half, lon - half, 2 * half / n, 2 * half / n, 10));
    view.fine = [lat, lon, half];
  }
  function diveTo(lat, lon, ms) {
    if (!alive) return Promise.resolve();
    var dLon = ((lon - view.lon) % 360 + 540) % 360 - 180;            // the short way round
    if (dLon > -60 && dLon < 0) dLon += 360;                          // never spin backwards: carry on round, eastwards
    return new Promise(function (res) { dive = { t0: performance.now(), ms: ms, lat0: view.lat, lat: lat, lon0: view.lon, dLon: dLon, d0: view.dist, resolve: res, done: false }; });
  }
  function stop() {
    alive = false; cancelAnimationFrame(raf);
    if (gl) { var lose = gl.getExtension('WEBGL_lose_context'); if (texMain) gl.deleteTexture(texMain); if (texFine) gl.deleteTexture(texFine); if (lose) lose.loseContext(); }
    gl = null;
  }
  MW.globe = { start: start, focus: focus, dive: diveTo, stop: stop, get running() { return alive; }, view: view };
})();
