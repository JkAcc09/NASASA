/* globe.js — MW.globe: Mars and Phobos turning on the start screen.
 *
 * Mars is drawn by WebGL from NASA's colour map of the planet (mars-color.jpg: the Viking orbiter colour mosaic, from
 * NASA's 3D Resources), with the relief of the app's own terrain pack (MGS MOLA heights every 0.25°) shaded into it,
 * so Olympus Mons, Valles Marineris, Hellas and the polar caps are sharp and in their real places. Phobos (phobos.jpg,
 * NASA 3D Resources) circles it every 40 s, passing in front of the planet and behind it. Mars turns once in 100 s.
 * If the colour map cannot be read, Mars is coloured by height alone from the terrain pack.
 *
 *   MW.globe.start(canvas, place, art)   art = { mars: <img>, phobos: <img> }; place(w, h) gives the planet's centre
 *                                        and radius in CSS px. Resolves true once Mars shows, false if this browser
 *                                        cannot draw it (no WebGL)
 *   MW.globe.onFrame(fn)                 fn(t, place) every frame, for whatever moves with the scene (intro.js: the orbiter)
 *   MW.globe.stop()                      stop drawing and free the GPU memory
 */
(function () {
  'use strict';
  var DEG = Math.PI / 180;
  var gl = null, cv = null, prog = null, U = {}, texMars = null, texPhobos = null, raf = 0, placeFn = null, alive = false, frameFns = [];
  var view = { lon: 30, t0: 0 };
  var SPIN = 3.6, PHOBOS_S = 40;                                     // degrees a second; seconds per Phobos orbit
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------------------------------------------------------------- textures */
  function smooth(e0, e1, x) { var t = Math.max(0, Math.min(1, (x - e0) / (e1 - e0))); return t * t * (3 - 2 * t); }
  /* The colour map, with MOLA relief shaded into it (the colour map has some shading of its own; this sharpens it). */
  function marsPixels(img) {
    var W = 1440, H = 720, c = document.createElement('canvas'); c.width = W; c.height = H;
    var g = c.getContext('2d'); g.drawImage(img, 0, 0, W, H);
    var d = g.getImageData(0, 0, W, H), px = d.data, T = MW.terrain;
    if (T && T.ready) {
      var z = new Float32Array(W * H), i, j, M = 3389500 * DEG * 0.25, sx = -0.62, sy = 0.62, sz = 0.48, n = Math.hypot(sx, sy, sz);
      sx /= n; sy /= n; sz /= n;
      for (j = 0; j < H; j++) { var la = 90 - (j + 0.5) * 0.25; for (i = 0; i < W; i++) z[j * W + i] = T.heightAt(la, -180 + (i + 0.5) * 0.25) || 0; }
      for (j = 0; j < H; j++) {
        var dx = Math.max(0.05, Math.cos((90 - (j + 0.5) * 0.25) * DEG)) * M;
        for (i = 0; i < W; i++) {
          var k = j * W + i, xl = i > 0 ? k - 1 : k + W - 1, xr = i < W - 1 ? k + 1 : k - W + 1, yu = j > 0 ? k - W : k, yd = j < H - 1 ? k + W : k;
          var gx = (z[xr] - z[xl]) / (2 * dx) * 14, gy = (z[yu] - z[yd]) / (2 * M) * 14;
          var sh = (-gx * sx + gy * sy + sz) / Math.sqrt(gx * gx + gy * gy + 1) / sz;   // 1 on level ground
          var f = 0.82 + 0.18 * Math.max(0, Math.min(1.9, sh)), o = k * 4;
          px[o] = Math.min(255, px[o] * f); px[o + 1] = Math.min(255, px[o + 1] * f); px[o + 2] = Math.min(255, px[o + 2] * f);
        }
      }
    }
    return px;
  }
  /* Without the colour map: colour by height, as 1.9 did. */
  var STOPS = [[-8200, 52, 24, 17], [-5500, 88, 40, 26], [-3800, 122, 56, 33], [-2000, 150, 72, 40], [0, 176, 92, 52], [1800, 192, 110, 66],
               [3500, 204, 128, 84], [6000, 212, 146, 104], [11000, 222, 170, 132], [21500, 240, 222, 200]];
  function ramp(h) {
    if (h <= STOPS[0][0]) return STOPS[0].slice(1);
    for (var i = 1; i < STOPS.length; i++) if (h <= STOPS[i][0]) { var a = STOPS[i - 1], b = STOPS[i], t = (h - a[0]) / (b[0] - a[0]); return [a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t, a[3] + (b[3] - a[3]) * t]; }
    return STOPS[STOPS.length - 1].slice(1);
  }
  function heightPixels() {
    var W = 1440, H = 720, px = new Uint8Array(W * H * 4), T = MW.terrain;
    for (var j = 0; j < H; j++) {
      var lat = 90 - (j + 0.5) * 0.25, cap = lat > 0 ? smooth(78.5, 83, lat) : smooth(-82.5, -85.5, lat);
      for (var i = 0; i < W; i++) { var c = ramp(T.heightAt(lat, -180 + (i + 0.5) * 0.25) || 0), o = (j * W + i) * 4; px[o] = c[0] * (1 - cap) + 238 * cap; px[o + 1] = c[1] * (1 - cap) + 232 * cap; px[o + 2] = c[2] * (1 - cap) + 226 * cap; px[o + 3] = 255; }
    }
    return px;
  }
  function texture(unit, W, H, px) {
    var t = gl.createTexture(); gl.activeTexture(gl.TEXTURE0 + unit); gl.bindTexture(gl.TEXTURE_2D, t);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, W, H, 0, gl.RGBA, gl.UNSIGNED_BYTE, px instanceof Uint8Array ? px : new Uint8Array(px.buffer));
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    return t;
  }
  function imgPixels(img, W, H) { var c = document.createElement('canvas'); c.width = W; c.height = H; var g = c.getContext('2d'); g.drawImage(img, 0, 0, W, H); return g.getImageData(0, 0, W, H).data; }
  function loaded(img) {
    if (!img) return Promise.resolve(null);
    return (img.complete && img.naturalWidth ? Promise.resolve() : new Promise(function (res, rej) { img.addEventListener('load', res, { once: true }); img.addEventListener('error', rej, { once: true }); }))
      .then(function () { return img.naturalWidth ? img : null; }, function () { return null; });
  }

  /* ---------------------------------------------------------------- the shader: a ray to a sphere, per pixel */
  var VS = 'attribute vec2 a;void main(){gl_Position=vec4(a,0.,1.);}';
  var FS = [
    'precision highp float;',
    'uniform vec2 C;uniform float R,tl,ln,haze;uniform sampler2D tm;',
    'const float PI=3.14159265;',
    'void main(){',
    ' float th=tan(asin(1./3.2));',
    ' vec2 p=(gl_FragCoord.xy-C)/R*th;',
    ' vec3 o=vec3(0.,0.,3.2),d=normalize(vec3(p,-1.));',
    ' float b=dot(o,d),c=dot(o,o)-1.,h=b*b-c;',
    ' vec3 L=normalize(vec3(.62,.38,.69));',                            // the Sun to the upper right: the lit face looks into the screen
    ' float closest=length(o-d*b);',
    ' if(h>0.){',
    '  vec3 n=normalize(o+d*(-b-sqrt(h)));',
    '  float cs=cos(tl),sn=sin(tl);',
    '  vec3 q=vec3(n.x,n.y*cs+n.z*sn,-n.y*sn+n.z*cs);',
    '  float lat=asin(clamp(q.y,-1.,1.)),lon=ln+atan(q.x,q.z);',
    '  vec3 base=texture2D(tm,vec2(fract((lon/PI+1.)*.5),.5-lat/PI)).rgb;',
    '  float di=dot(n,L),lit=smoothstep(-.1,.6,di);',
    '  float rim=pow(1.-max(dot(n,-d),0.),2.5);',
    '  vec3 rgb=base*(.035+1.02*lit)+vec3(1.,.58,.38)*rim*.45*lit*haze;',
    '  gl_FragColor=vec4(rgb,1.);',
    ' } else if(haze>0.){',
    '  float g=1.-smoothstep(1.,1.08,closest);',
    '  float a2=g*g*.6*clamp(dot(normalize(o-d*b),L)*.9+.35,0.,1.);',
    '  gl_FragColor=vec4(vec3(1.,.56,.36),a2);',
    ' } else discard;',
    '}'].join('\n');
  function shader(type, src) { var s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s)); return s; }

  function size() {
    var dpr = Math.min(window.devicePixelRatio || 1, 1.5), w = cv.clientWidth, h = cv.clientHeight;
    if (cv.width !== Math.round(w * dpr) || cv.height !== Math.round(h * dpr)) { cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr); }
    return { w: w, h: h, dpr: dpr };
  }
  function sphere(tex, unit, x, y, r, tilt, lon, haze, s) {
    gl.uniform1i(U.tm, unit); gl.uniform2f(U.C, x * s.dpr, (s.h - y) * s.dpr); gl.uniform1f(U.R, r * s.dpr);
    gl.uniform1f(U.tl, tilt * DEG); gl.uniform1f(U.ln, lon * DEG); gl.uniform1f(U.haze, haze);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
  }
  function draw(ts) {
    if (!alive) return;
    raf = requestAnimationFrame(draw);
    var t = reduce ? 0 : (ts - view.t0) / 1000, s = size(), at = placeFn(s.w, s.h);
    view.lon = (30 + SPIN * t) % 360;
    gl.viewport(0, 0, cv.width, cv.height); gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT);
    /* Phobos: an orbit seen nearly edge-on and tilted, 1.9 Mars radii out (it is really 2.8), a fifteenth of Mars' size */
    var a = (t / PHOBOS_S) * 2 * Math.PI + 0.9, ox = Math.cos(a) * 1.9, oz = Math.sin(a) * 1.9, oy = Math.sin(a) * 0.22 + Math.cos(a) * -0.12;
    var tilt = -16 * DEG, px = at.x + at.r * (ox * Math.cos(tilt) - oy * Math.sin(tilt)), py = at.y - at.r * (ox * Math.sin(tilt) + oy * Math.cos(tilt));
    var pr = at.r * 0.075 * (1 + oz * 0.06), front = oz > 0;
    if (texPhobos && !front) sphere(texPhobos, 1, px, py, pr, 0, -a / DEG + 90, 0, s);
    sphere(texMars, 0, at.x, at.y, at.r, 14, view.lon, 1, s);
    if (texPhobos && front) sphere(texPhobos, 1, px, py, pr, 0, -a / DEG + 90, 0, s);
    for (var i = 0; i < frameFns.length; i++) frameFns[i](t, at, s);
  }

  function start(canvas, place, art) {
    cv = canvas; placeFn = place; art = art || {};
    try { gl = cv.getContext('webgl', { premultipliedAlpha: false, alpha: true, antialias: false }) || cv.getContext('experimental-webgl'); } catch (e) { gl = null; }
    if (!gl) return Promise.resolve(false);
    var terrain = MW.terrain ? MW.terrain.load().then(function () { return true; }, function () { return false; }) : Promise.resolve(false);
    return Promise.all([loaded(art.mars), loaded(art.phobos), terrain]).then(function (r) {
      var marsImg = r[0], phobosImg = r[1], hasTerrain = r[2];
      if (!marsImg && !hasTerrain) return false;
      prog = gl.createProgram(); gl.attachShader(prog, shader(gl.VERTEX_SHADER, VS)); gl.attachShader(prog, shader(gl.FRAGMENT_SHADER, FS)); gl.linkProgram(prog);
      if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(prog));
      gl.useProgram(prog);
      var buf = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, buf); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
      var a = gl.getAttribLocation(prog, 'a'); gl.enableVertexAttribArray(a); gl.vertexAttribPointer(a, 2, gl.FLOAT, false, 0, 0);
      ['C', 'R', 'tl', 'ln', 'haze', 'tm'].forEach(function (n) { U[n] = gl.getUniformLocation(prog, n); });
      gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
      texMars = texture(0, 1440, 720, marsImg ? marsPixels(marsImg) : heightPixels());
      if (phobosImg) texPhobos = texture(1, 512, 256, imgPixels(phobosImg, 512, 256));
      view.colour = !!marsImg; view.relief = hasTerrain;
      alive = true; view.t0 = performance.now(); raf = requestAnimationFrame(draw);
      return true;
    }).catch(function (e) { if (window.console) console.warn('Globe not drawn: ' + e.message); return false; });
  }
  function stop() {
    alive = false; cancelAnimationFrame(raf); frameFns = [];
    if (gl) { var lose = gl.getExtension('WEBGL_lose_context'); if (texMars) gl.deleteTexture(texMars); if (texPhobos) gl.deleteTexture(texPhobos); if (lose) lose.loseContext(); }
    gl = null;
  }
  MW.globe = { start: start, stop: stop, onFrame: function (fn) { frameFns.push(fn); }, get running() { return alive; }, view: view };
})();
