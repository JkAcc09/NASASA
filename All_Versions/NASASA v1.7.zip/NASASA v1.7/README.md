# Marswalk

A field map for one Marswalk (EVA) at the Mount Sharp boxwork in Gale crater, built for the
NASA Space Apps 2026 challenge "Interplanetary Survival Guide: Martian Map".

It shows a layered NASA map of the site, a pointer for where the walker (astronaut or robot) is
and which way they are looking, and a trail that remembers every pass over the same ground in order.
Trails can be recorded per walker, saved, replayed and shared as files. Named landmarks can be tapped
for their details and outline, and the look and controls are adjustable in Settings.
You can put your own markers anywhere on the planet, and ask for the ways to any point: each route gets
a safety index and the reasons for it, or a plain statement of why no route is viable.

![Night infrared over the HiRISE photo map, with Curiosity's route](night-infrared-over-hirise.jpg)

## The look: Mission Control (1.7)

Since 1.7 the app is a dark console. On a wide screen with the map first, the map fills the window and
the top bar, the panel rail, the column and the readouts float over it as see-through panels. Numbers are
set in JetBrains Mono so they do not jitter as they change; everything else is Space Grotesk (both from
Google Fonts, kept by the offline store; without them the page falls back to system fonts). One accent
colour marks what is active; magenta is still the walker's own trail.

What the map does by itself keeps clear of the panels: notices, the rover view, the scale, the status chips
and the attribution sit in the open part of the map (the lengths `--inset-t`, `--inset-l`, `--inset-r` on
`#app` in `style.css`), and popups, routes and places are fitted into it (`syncInsets` and `MW.ui.fitPad`
in `app.js`, which measure the panels, because the bar can wrap and the column and readouts fold away).
"Numbers first" and narrow screens keep their own layouts, in the same colours.

Settings > App colours has eight themes: **Console** (cyan, the default), **Graphite**, **Ember** (amber),
**Aurora** (green), **Nebula** (violet), **Night red** (keeps eyes adjusted to the dark), **Daylight** (a light
console for a lit room) and **Direct sun** (black on white, no glass). A theme saved by an earlier version opens
as its nearest console theme (`THEMES_BEFORE_1_7` in `config.js`): Blue and Night blue as Console, Grey and Black
as Graphite, Sand as Ember, Green and Night teal as Aurora, Violet as Nebula. The Settings page has a section
list on the left that scrolls to each card.

## Run it

- **Quickest:** open `marswalk.html` in Chrome, Edge or Firefox. It is the whole app in one file.
- **From source:** open `index.html`, or serve the folder with `python -m http.server` and open
  `http://localhost:8000`.
- **GitHub Pages:** see "Publishing on GitHub Pages" below. There is no build step.

The map imagery streams from NASA's Mars Trek tile server, so the browser needs internet access the first
time. Served from a web address (localhost or Pages), the page keeps itself and every tile you view, and
"Save the walk area" in the Map Overlay tab fetches the rest of the walk area ahead of time; after that it
opens and shows the map without a connection (see "Offline map"). Opened as a file, it cannot do this.
If the tiles cannot be reached the page says so; the route, pointer and trail still work.

### Publishing on GitHub Pages

1. Merge into the branch you want to publish (usually `main`) and push it.
2. On GitHub: **Settings > Pages > Build and deployment > Source: Deploy from a branch**, branch `main`,
   folder `/ (root)`, **Save**.
3. After a minute or two the site is at `https://<owner>.github.io/<repository>/`; `index.html` is the page.

Pages serves the files as they are: `index.html` loads the separate scripts, `marswalk.html` is the
single-file copy. Over https the offline store works as it does on localhost.

## Where things live

Plain JavaScript, no framework and no build step. Each file adds to one global object, `MW`,
and they load in this order (see the bottom of `index.html`). Every file sits beside `index.html`.

| File | What it holds | Edit it when you want to… |
|---|---|---|
| `config.js` | Every constant, colour ramp and map layer | add or change a layer, tune the trail, change walking speed |
| `data.js` | The NASA data pack: Curiosity's route, REMS weather, Navcam photo ids | move to another site or refresh the data |
| `geo.js` | Unpacks `data.js`; coordinate conversion; number and text formatting | change the coordinate model |
| `tiles.js` | `MW.SmoothTiles`: the tile layer (over-zoom, recolouring, reading values) | change how tiles are drawn or sampled |
| `trail.js` | `MW.Trail`: trail points, pass counting, way back, saved-trail format | change what counts as "the same ground" |
| `store.js` | `MW.store`: saved trails in the browser's storage | keep trails somewhere else (a server, a suit computer) |
| `markers.js` | `MW.markers`: the user's markers, the four built-in icons, uploaded icons, the filter | change what a marker holds or how an icon is drawn |
| `landmarks.js` | `MW.landmarks`: named places, their outlines, the rules for showing names | add a landmark or change when names appear |
| `ui.js` | `MW.ui`: the line icons on buttons and their hover labels | add a button icon |
| `settings.js` | `MW.settings`: the user's choices and the Settings panel | add a setting |
| `app.js` | The page: map, pointer, movement, recording, readouts, main loop | change behaviour or the interface |
| `trail-edit.js` | `MW.trailEdit`: the on-map editor for the trail walked so far | change how a trail is edited |
| `dust-data.js` | The dust data pack: observed dust optical depth, MY24 to MY36 (written by `dust_ingest.py`) | never by hand: rebuild it |
| `dust.js` | `MW.dust`: seasonal baseline, anomaly detection, classes, route exposure. No map, no page | change how dust activity is detected |
| `dust-ui.js` | The DUST STORM ACTIVITY layer, timeline, dust monitor and route warnings | change how dust is shown |
| `terrain-data.js` | The terrain pack: height above the MOLA reference level, whole planet (written by `terrain_ingest.py`) | never by hand: rebuild it |
| `terrain.js` | `MW.terrain`: height and regional slope at any point. No map, no page | change how height is read |
| `router.js` | `MW.router`: the route-finder and the safety index. No map, no page | change how routes are found or scored |
| `budget.js` | `MW.budget`: oxygen, battery and the turn-back point (modelled). No map, no page | change the consumables model |
| `places.js` | `MW.places`: what the location selector offers, checkpoints, view links. No map, no page | add a kind of place |
| `places-ui.js` | "Go to a place" in the Menu tab: search, View, Walk from here, checkpoints, the address bar | change how places are shown |
| `season.js` | `MW.season` and the "Best season for a walk here" chart in the Dust Storm tab | change how the season is judged |
| `companions.js` | "Walk together" in the Menu tab: the other walkers on the map at once | change how companions move |
| `offline.js` | "Offline map" in the Map Overlay tab; registers `sw.js` | change which tiles are saved |
| `sw.js` | The service worker: keeps the app and the map tiles for use without a connection | change what is kept |
| `lazy.js` | Loads the dust packs after the map's first view | defer another large file |
| `hud.js` | The readout tabs beside the map, and the mission status symbols at its bottom right | change how readouts are grouped |
| `context-menu.js` | The right-click (long-press) menu on the map: image, reveal, travel, mark | add a choice to the menu |
| `imagery.js` | `MW.imagery`: the best NASA picture of a place (Curiosity's Navcam or orbital), and its panel | change where pictures come from |
| `o2-model.js` | Settings > Walk budget: oxygen model, the user's own oxygen numbers | add a field to the oxygen model |
| `nav-ui.js` | The Markers and routes tab: marker form, icon picker, filter, route search, result cards, lines on the map | change how markers and routes are shown |
| `terrain_ingest.py` | Builds `terrain-data.js` from the MarsTopo719 shape model and the GMM-3 gravity model | change the terrain resolution |
| `router_test.js` | Checks the terrain pack and the route-finder against the real data: `node router_test.js` | you changed `router.js`, `terrain.js` or a limit |
| `dust_ingest.py` | Downloads the dust climatology and writes `dust-data.js` | refresh the data, or change its resolution |
| `dust_test.js` | Checks the detection against the real data: `node dust_test.js` | you changed `dust.js` or a threshold |
| `features_test.js` | Checks the walk budget, places, sites, slope and the season planner: `node features_test.js` | you changed one of those |
| `page_test.js` | Opens the page in headless Chrome or Edge and checks it end to end, offline included: `node page_test.js` | before you share a version |
| `package.py` | Zips the app for sharing: `python package.py 1.6` writes `All_Versions/NASASA v1.6.zip` | you want to hand out a version |
| `style.css` | All styling. The themes are at the top; the Mission Control layer (floating panels, controls) is the last section | change the look |
| `build.py` | Packs everything into `marswalk.html` | you changed any file above: run `python build.py` |
| `leaflet.js`, `leaflet.css` | Leaflet 1.9.4, unmodified | – |

`app.js` is divided into eight numbered sections listed at its top. `trail.js` and `store.js`
do not touch the map or the page, so they can be reused or tested on their own.
Choices offered in Settings (trail palettes, pointer colours, themes, display and movement modes,
default walkers) are plain lists in `config.js`; theme colours are the `body[data-theme]` blocks
at the top of `style.css`.

### Common changes

**Add a map layer.** Find the layer on the
[Trek layer list](https://trek.nasa.gov/tiles/apidoc/trekAPI.html?body=mars), then add one entry
to `LAYERS` in `config.js`:

```js
{ key: 'my-layer', name: 'Name in the list', id: 'Trek_Layer_Name', ext: 'png', nz: 9, res: '100 m',
  read: 'grey', ramp: 'heat', stretch: true, ends: ['cooler', 'warmer'], what: 'ground warmth',
  note: 'One or two sentences on what the layer shows and how to read it.' }
```

`nz` is the deepest zoom the server really has: request
`{TREK}{id}/1.0.0/default/default028mm/{z}/{y}/{x}.{ext}` at rising `z` until it returns 404.
The fields `read`, `ramp`, `stretch`, `legend`, `ends` and `what` are explained above `LAYERS`.
The legend bar, the readout under the map and the tick on the bar all follow from the entry.

**Add a landmark.** Add one entry to `LIST` in `landmarks.js`; the comment at the top of that
file explains each field. Its name, outline, popup and visit counts follow from the entry.

**Add a colour theme.** Add a `body[data-theme="name"]` block in `style.css` with the same variables as the
others (the comment above them says what each is for), and the name to `THEMES` in `config.js`. A light theme
also needs adding to the `color-scheme: light` rule and to the light status colours just below the themes.

**Feed a real position.** Call this from any script, as often as fixes arrive:

```js
Marswalk.setPose({ lat: -4.8012, lon: 137.3829, heading: 215 });   // heading: degrees clockwise from north
Marswalk.releasePose();                                            // hand control back to the page
```

**Move to another site.** Replace the three strings in `data.js` (the comment at its top gives
each source and encoding) and the `BASE` layers and bounds in `config.js`.

## What is on the map

| Kind | Layer | Source (Trek layer id) | Deepest real zoom | Ground per pixel |
|---|---|---|---|---|
| Optical | Photo base | MRO HiRISE `curiosity_hirise_mosaic` | 16 | 0.6 m |
| Optical | Photo base, surroundings | MRO CTX `Gale_CTX_BlockAdj_dd` | 12 | 10 m |
| Optical | Photo base, planet | Viking `Mars_Viking_MDIM21_ClrMosaic_global_232m` | 7 | 325 m |
| Thermal | Daytime and night infrared | Odyssey THEMIS `THEMIS_DayIR/NightIR_ControlledMosaics_100m_v2_oct2018` | 9 | 100 m |
| Topographic | Colour elevation, shaded relief | MOLA + HRSC `Mars_MOLA_blend200ppx_HRSC_*` | 8 | 200 m |
| Spectral, chemical | Clinopyroxene, plagioclase, glass and clay, albedo | MGS TES `TES_*` | 1 | regional |
| Geophysical | Thermal inertia, dust cover, roughness | MGS TES, MGS MOLA | 1 | regional |
| Atmospheric | Air and ground temperature, pressure, UV at every route stop | Curiosity REMS | per sol | in place |
| Atmospheric | Dust storm activity: column dust optical depth | Montabone et al. climatology v2 (MGS TES, Odyssey THEMIS, MRO MCS) | 5-sol means, MY24–36 | 6° × 5° (about 355 × 296 km) |
| Topographic | Height and regional slope for the route-finder | MarsTopo719 shape model (MGS MOLA) on the GMM-3 areoid | 0.25° planet, 0.0625° Gale | about 15 km |
| Radiation | Dose rate and dose for this walk | Model on the RAD surface average, 0.67 mSv/day | modelled | – |
| Point of view | Navcam photo at every third stop | Curiosity raw images | per stop | – |

The reference route is Curiosity's real drive: 120 end-of-drive positions from sol 4560 to 5073,
2.9 km long with 175 m of climb. Base (0, 0) is the first of them.

## How the readings work, and what they are not

Every data layer has the same legend bar: a low word, the colours, a high word, and a tick at the
walker's own value. The same value is shown as a number under the map.

- **Thermal layers** are greyscale pictures. The page stretches the grey range inside the current
  view across a blue-to-red ramp. The number is *relative to the view*: 0 is the coolest ground in
  view, 100 the warmest. The THEMIS mosaics are normalised, so they do not carry kelvin.
- **Mineral, thermal-inertia and dust layers** come from Trek already painted in a rainbow. The page
  reads the hue back into a number (violet 0, red 100) and repaints it on one pale-to-deep ramp, so
  deeper always means more. The scale is fixed. The direction was checked against known regions
  (dusty Arabia reads high dust and low thermal inertia; Syrtis Major reads high pyroxene and
  plagioclase). The number is a position on NASA's colour scale, not a physical unit: Trek does
  not publish the unit range of these colour scales.
- **Albedo** is a greyscale picture on the same fixed pale-to-deep ramp.
- **Roughness** is NASA's three-channel composite; the readout gives the three channels.
- **Colour elevation** keeps NASA's colours; the readout gives the surveyed height in metres.
- **Weather** numbers are Curiosity's measured daily low and high; the hour-by-hour curve between
  them, and all radiation figures, are models and are labelled so on the page.

To get physical units for the regional layers, the next step is to download the numeric TES grids
from the PDS and sample those instead of the pictures.

## Dust storm activity

A detection and early-warning layer built on real orbital observations. It reports what was observed
and how unusual it was for the place and season. **It does not forecast.**

### The data

Column dust optical depth, in infrared absorption at 9.3 µm, normalised to 610 Pa, from
[Montabone et al., Climatologies of the Martian Atmospheric Dust Optical Depth, v2](https://www-mars.lmd.jussieu.fr/mars/dust_climatology/index.html)
(Icarus 2015, doi:10.1016/j.icarus.2014.12.034; JGR Planets 2020, doi:10.1029/2019JE006111; CC BY-SA 3.0).
The climatology is built from NASA retrievals: MGS TES, Mars Odyssey THEMIS and MRO
[Mars Climate Sounder](https://pdsatmospheres.nmsu.edu/data_and_services/atmospheres_data/MARS/aerosols.html).
From MY34 on it is MCS alone.

`python dust_ingest.py` reads the NetCDF files straight from the server (only the variables it needs,
no extra packages), averages them to 6° × 5° cells and 5-sol frames, and writes `dust-data.js`:
13 Martian Years, 134 frames a year, 2,160 cells. For every cell and frame it keeps the optical depth,
its relative uncertainty, the data set's reliability value, the Ls, the sol and the instruments.
`--years 34 35` builds a subset; `--inspect 34` lists what is in a year's files.

Every number on the page carries one of four labels:

| Label | Meaning here |
|---|---|
| OBSERVED | a cell of the observation-only maps (`griddedcdod`) for those sols |
| HISTORICAL | statistics of OBSERVED values from the other Martian Years: the seasonal baseline |
| INTERPOLATED | the kriged complete-coverage maps (`dustscenario`), used only where there is no observation, only when an observation exists within 10 sols or in a neighbouring cell, and drawn on the map only if "Fill gaps" is ticked |
| MODELLED | not used: no dust value is a model output |

A cell with neither is NO DATA. It is drawn grey and is never treated as clear air.

### The detection (`dust.js`, thresholds in `DUST` in `config.js`)

1. **Baseline.** For each cell and season: every OBSERVED value within ±10° of Ls, from every Martian Year
   except the one being judged. This gives a median, a 90th percentile and a robust spread
   (1.4826 × the median absolute deviation, never less than 15 % of the median or 0.02).
   It needs 6 values from 3 other years.
2. **Anomaly.** z = (optical depth − median) ÷ spread; deviation = (optical depth − median) ÷ median.
3. **Persistence.** How many consecutive observed frames, ending at this one, were elevated.
4. **Region.** How many of the 8 neighbouring cells are elevated in the same frame.
5. **Trend.** A straight-line fit through the last 4 frames (20 sols): increasing, decreasing or stable
   (a change of at least 20 % of the mean and 0.03).
6. **Class.**

| Class | Criteria |
|---|---|
| LOW | not elevated: inside the normal range for the place and season |
| MODERATE | z ≥ 2 and optical depth ≥ 0.15. An elevated value that is neither persistent nor regional stays here, however high |
| HIGH | z ≥ 4 and optical depth ≥ 0.30, and persistent (2 frames, 10 sols) or regional (3 neighbours) |
| SEVERE | z ≥ 6 and optical depth ≥ 0.80, and persistent and regional |

The optical-depth floors are this project's own choices, not a published standard. Without a usable
baseline only the floors apply, the class is capped at HIGH and confidence is low. Confidence also drops
for interpolated values, retrieval uncertainty above 30 %, a baseline from fewer than 5 years, and
latitudes beyond 60°, where retrievals near the polar caps are less reliable.

A **storm event** is a run of frames in which HIGH or SEVERE cells cover at least 2 % of the observed
area between 60° S and 60° N. Run on the record, the detection finds the planet-encircling storms of
MY25, MY28 and MY34 without being told about them.

### On the page

- **Layer.** "DUST STORM ACTIVITY" in the legend column can be shown over any other layer. It is drawn as
  one rectangle per cell at the cell's true size. Colour it by optical depth, deviation from baseline,
  class or trend. A white line marks the edge of the HIGH or SEVERE region; a red triangle marks a rising cell.
- **Timeline.** Choose a Martian Year and an Ls range, step or play through the frames, replay a detected
  storm event, and compare with a second year (chart, monitor row, and a button to swap the years on the map).
- **Dust monitor.** For the walker's cell, or a cell tapped at Crater or Planet scale: optical depth,
  baseline, deviation, class, trend, regional activity, observation date, instrument, resolution,
  confidence, and how often this season was HIGH or SEVERE in the record.
- **Route.** The route being replayed is cut into sections, one per data cell, each with its class,
  measurements and the reasons. Elevated sections are highlighted on the map, with possible
  consequences: reduced visibility, harder surface operations, less solar power, timing to reassess.
  The astronaut strip shows the class at the walker's position; HIGH or SEVERE on the route raises a
  short notice on the map.

`MW.dustUI.goTo(34, 205)` jumps to a year and Ls; `MW.dustUI.show(true)` turns the layer on.

### What it is not

- Not a forecast, and not live: the newest observation in the pack is MY36, Ls 359° (December 2022).
  The class shown is for the frame selected on the timeline.
- Not a visibility or surface measurement. Optical depth describes the whole air column from orbit.
- Not local. One cell is about 355 × 296 km at Gale, so a Marswalk sits inside one cell and the data
  cannot tell one part of a short route from another.
- Dust cannot tell two paths inside one cell apart, so "Alternatives" here compares the stored routes and
  gives the historically clearest season for the place. The route-finder (Markers and routes) compares paths
  on everything else and refuses a destination in a SEVERE storm.
- The Mars Climate Sounder profiles on the PDS are not read directly; they enter through the climatology.
- Before MY28 the record rests on TES and THEMIS, with sparser coverage (32 % of grid points in MY27).

## Walkers, display modes and settings

A **walker** is a named astronaut or robot (Settings, or the Walker list in the top bar). Each saved
trail carries its walker's name and kind, and landmark visits are counted for the active walker.
There is one pointer on the map at a time: the active walker's.

Three **display modes** show the same data for different users:

| Mode | For | What changes |
|---|---|---|
| Planner | planning in the habitat | everything is shown |
| Astronaut | a glance through a visor | the legend column becomes a drawer; large readouts (looking, walked, back to base, time, dose); larger buttons |
| Robot | a rover or its operator | exact latitude and longitude (6 decimals), metres to the centimetre, heading to 0.1° |

In Planner and Robot on a wide screen, the tab on the legend column's right edge folds the column
away to give the map the full width; the choice is kept in the browser (key `marswalk.collarHidden`).
Where the column is a drawer (Astronaut, or a narrow screen), "Menu" opens it and × or Escape closes it.

The column has five parts, chosen with the tabs on its edge: **Menu** (trail, saved routes, route
measurements; shown first), **Markers and routes** (your markers, the filter, the route-finder),
**Map Overlay** (the data layers), **Dust Storm** (the dust layer, monitor and
route warnings) and **Timeline** (Martian Year, Ls range, playback, storm events). A section belongs to a
part through its `data-tab` attribute in `index.html`; `Marswalk.setTab('dust')` switches from code.

Small **(i)** buttons beside technical terms open a short explanation: what the value is and its unit, why it
matters on a walk, and whether it is measured, historical, interpolated or modelled. The texts are
`GLOSSARY` in `config.js`; any `<button class="info" data-info="key">` opens the entry with that key.

**Layout** (Settings > Display) has two choices. **Tabs beside the map** (the default) keeps the readouts in a
narrow column on the right, chosen by three square tabs on a rail at the readouts' left edge (the mirror of the panel tabs on the
left): **Position** (position, height, slope, bearing, distance, time), **Conditions** (safety index, map layer,
weather, radiation, dust) and **Budget** (oxygen, battery, turn back). One shows at a time; pressing the open one again
folds the column away and gives the map the width. A tab with nothing ticked is left out, and the choice, folded or
not, is kept (`marswalk.roTab`). A saved
"row" or "column" layout from an earlier version opens as this one. **Numbers first, mini-map**: the readouts fill
the main area as large cards, every group at once, the live safety index
gets the largest card with all its factors, and the map becomes a mini-map in the top right corner with the
rover view and walk pad beneath it. The mini-map is the same map: it follows the walker and takes taps.

Nothing in that layout scrolls. `fitNumbers` in `app.js` tries 2 to 8 columns of cards and keeps the
largest type size at which every ticked readout is in view and no number is broken across lines, so the size
follows the window and how many readouts are ticked: with the sixteen readouts there were before slope and
the walk budget were added, values were about 32 px at 1440 × 900 and 46 px at 1920 × 1080; with three on, over 60 px.
With all twenty on they are a little smaller. In a small window the factor list and the two headings
are dropped before the type falls under half size. In the side column the mini-map gives up height to the
notices (alarm, dust warning), and the rover view steps aside when under 120 px would be left for it. Below
about 1000 × 650 with everything on, the numbers get smaller than in the ordinary layout and that layout is
the better choice; under 861 px wide the page stacks (map on top, numbers beneath) and scrolls as a page.

**Settings** also change the trail's colour (five palettes, each four shades from pale to deep) and
width, the pointer's colour and size, how the pointer is moved (keys and taps, keys only, taps only)
and the app's colours (eight themes, see "The look" above). Choices are kept in the browser
(`localStorage`, key `marswalk.settings.v1`).

## Landmarks

31 named places: the main features and landing sites of the planet, and the places Curiosity has
worked in Gale crater. Tapping a name shows its function, size, the missions that have visited,
the active walker's own visits (this trail plus their saved trails) and a note, and draws its outline.

Names follow map conventions: higher rank and larger places show first and in larger type; a name
disappears when its place is too small to matter at the current zoom or has grown larger than the
screen; names never overlap, the higher rank wins. The thresholds are at the top of the label code
in `landmarks.js`.

What the outlines are, and are not:

- Planet-scale features and Gale crater are circles or ellipses from the catalogued centre and size.
  They are approximate.
- The Gale places (Yellowknife Bay to Gediz Vallis) are the ground Curiosity actually covered there,
  computed from its position fixes (`MSL_waypoints.json`) with a 25 m margin. They are not geological
  boundaries, and the sol range attached to each name is approximate.
- "Visited by missions" counts surface missions, not individual drives or sols.

## The trail

A point is stored every 1.5 m with its time, odometer and look direction. A new pass over a spot
is counted when the walker comes within 2.5 m of earlier trail after walking at least 12 m away
from it. The line is drawn as four canvas strokes (once, twice, three times, four or more), so
drawing cost does not grow with the number of colours. Tapping the trail lists every pass in order.
"Show way back" draws the trail in reverse with every loop cut out.

**Record, save, edit.** "Record a new trail" is the labelled button under "Your trail"; that panel and
"Saved routes and trails" show in both the Menu tab and the Markers and routes tab. You do not have to press
Record first: the popup that opens when you tap the trail has **Save this trail** and **Edit this trail**,
and the same two actions are the first two icons under the Record button.

**Editing** (`trail-edit.js`) works on a thinned copy of the trail: the fewest points that stay within a
metre of the walked line. Drag a point to move it; tap a point to delete it, end the trail there or start
it there; tap the line to add a point; Undo, Done and Cancel are in the bar on the map. Done lays the trail
again along the edited line (a point every 1.5 m, pass counts worked out afresh, times at the pace walked so
far) and puts the walker at its end. The walker stands still while the editor is open.

**The right-click menu** (`context-menu.js`). Right-click a spot on the map, or hold a finger on it for 0.6 s on a
touch screen, for a small menu beside it:

- **View location image**: a small preview of the best NASA picture of the spot, with its source and date (see
  "Pictures of places" below), or "No imagery available for this location."
- **Reveal information**: a popup with the spot's coordinates, height and slope (Curiosity's survey on the drive,
  the regional model elsewhere), distance, bearing and walking time from the walker, the safety index and dust
  there, the map layer's value, the weather on arrival (near Gale), the dose rate, the place it lies in, the
  sharpest imagery and the nearest Curiosity stop.
- **Travel to location**: moves the walker there, as "Walk from here" does (the base stays within 60 km, a new site
  starts beyond). If a trail is under way it first asks: save it, travel anyway, or cancel.
- **Mark as landmark**: opens the marker form at that spot, to give it a name, a description and an icon.

Escape, a click elsewhere or moving the map closes it; the click that closes it does not walk the pointer. The
browser's own right-click menu is held back on the map only; everywhere else right-click works as usual.

**Mission status.** Three small symbols at the bottom right of the map, always shown whatever tab or layout:
**O₂** and **battery** (percent left, from the walk budget) and the **live safety index** (a shield). They turn
amber at 30 % left and red at the 15 % reserve, or when that one sets the turn-back point and it has passed; the
safety index is green from 75, amber from 50 and red below. A label names each value, and a press explains it.

### Saved trails

"Record a new trail" starts a fresh trail; "Stop and save" names and stores it in the browser
(`localStorage`, key `marswalk.trails.v1`). A saved trail can be shown on the map, replayed
(the pointer waits at its start until Start is pressed), downloaded and imported. The file is JSON:

```json
{ "format": "marswalk-trail", "version": 1, "id": "t…", "name": "Ridge loop",
  "savedAt": "2026-11-14T08:30:00.000Z", "source": "walked", "walker": { "name": "Astronaut 1", "type": "astronaut" },
  "site": "Mount Sharp boxwork, Gale crater, Mars", "base": { "lat": -4.799847, "lon": 137.383541 },
  "distance_m": 84.2, "duration_s": 157,
  "fields": ["lat", "lon", "seconds", "heading_deg"],
  "points": [[-4.8260233, 137.388886, 0, 188], …] }
```

## Markers and routes

The second tab on the column's edge. `Marswalk.openTab('nav')` opens it from code.

### Markers

Press **+** and tap the map, press the locate button to mark where the walker stands, or right-click
(long-press) the map and choose **Mark as landmark**. A marker can go anywhere on the planet. It holds a name, a description, an icon and
its position; the description takes a little Markdown (`**bold**`, `*italic*`, `` `code` ``, `- ` lists,
`[links](https://…)`), and anything else is shown as typed. Drag the pin to move it before saving.

| Icon | What the route-finder does with it |
|---|---|
| Pin (default) | nothing: a note or a destination |
| Home | counts as a base: "distance from the nearest base" and the way back are measured to it |
| Crater | nothing: a landform worth finding again |
| Danger | routes stay outside its keep-clear distance (50 m unless you set another), and pay for passing close |

A marker can also carry a **photo**: in the marker form, "Add a photo" takes a PNG, JPEG or WebP picture of up to
10 MB, shrinks it to 800 pixels (a JPEG of at most about 300 KB) and keeps it in the browser
(`marswalk.marker-photos.v1`), so it is still there after a refresh. It shows in the marker's details; "Replace the
photo" and "Remove" change it. If the browser has no room left, the marker is saved and the message says the photo was
not kept.
| Your own | nothing. The **+** beside the four icons uploads a picture; it is shrunk to a 64 px PNG and kept for reuse (up to 12) |

**Show on the map** is the filter: one tick per icon kind, one for markers with your own icons, one for the
NASA place names, and an eye beside each marker in the list to hide just that one. Everything is on until
you untick it; "Show everything" puts it all back. Markers, icons and the filter are kept in the browser
(`localStorage`, keys `marswalk.markers.v1`, `marswalk.marker-icons.v1`, `marswalk.marker-filter.v1`).

### Finding a route

Type a marker or place name, or a latitude and longitude, in **Route to**; or press the target and tap the
map; or press "Route here" on a marker. Routes start where the active walker stands and are scored for that
walker (astronaut or robot), for the departure time in **Leave at**, and for the dust observed on the date
chosen on the Timeline.

If no route is viable the bar says so, with the reason:

| Reason | When |
|---|---|
| too far | the straight line is longer than the walker can cover at all (astronaut: 8 h at 1.2 m/s; robot: 30 sols of 6 h at 4 cm/s) |
| dust storm | the start or the destination is in a SEVERE storm |
| keep-clear distance | the destination is inside a danger marker's radius |
| hazard area | the destination is inside a landmark whose role is a hazard (Bagnold Dunes) |
| regional slope | the land at the destination is steeper than the limit (astronaut 18°, robot 22°) |
| closed ground | every way there crosses one of the above |
| out and back | the walk there plus the way back to the nearest base is longer than 8 h |
| climb | the way there climbs more than 1,500 m (astronaut) |

Otherwise the routes are listed safest first. Each card shows its **safety index** (0 to 100, higher is
safer), the travel distance, the time, up to three reasons it is safe and up to four reasons it is not, as
short tags. The first card is the recommendation. "Follow this route" makes it the route the pointer follows.

### The algorithm (`router.js`, every limit and weight in `ROUTER` in `config.js`)

1. **Grid.** The ground between the two points, with room either side, is cut into at most 120 × 120 cells.
   Each cell gets its height and regional slope from the terrain pack, is closed if it is too steep or inside
   a hazard, and is flagged if a known trail runs through it (Curiosity's drive, every saved trail, the
   trail being walked now).
2. **Search.** A* over that grid, up to five times, each with a different cost: *Balanced* (distance, slope,
   climb, hazard clearance, a discount on known ground), *Known ground* (a large discount on known ground),
   *Most direct* (distance only), *Alternative* (balanced, but kept away from the balanced route) and
   *Along your preferred trail* (a very large discount on the starred trail). Stair-steps are straightened
   where the straight line costs no more; routes that come out the same are merged.
3. **Measure.** Distance, climb, steepest regional slope, time (Naismith's rule for climb), the way back,
   farthest point from a base, daylight and temperature over the outing, dust class along the line, share on
   known ground, clearance from danger markers.
4. **Score.** Each measurement becomes a risk from 0 to 1:

| Factor | Risk is 0 at | Risk is 1 at (astronaut) | Weight, astronaut / robot |
|---|---|---|---|
| Dust | LOW | SEVERE (HIGH 0.85, MODERATE 0.45, no data 0.4; +0.1 if rising) | 0.20 / 0.24 |
| Regional slope | 6° | 18° | 0.12 / 0.20 |
| Climb | 0 m | 600 m | 0.08 / 0.08 |
| Distance from nearest base | 0 m | 5 km | 0.14 / 0.04 |
| Time, out and back | 0 h | 8 h | 0.14 / 0.18 |
| Temperature drop | 0 °C | 40 °C | 0.08 / 0.02 |
| Daylight | back with over 1 h of light | the whole outing in the dark | 0.10 / 0 |
| Unwalked ground | all on known trails | 2 km of ground nobody has walked | 0.08 / 0.14 |
| Hazard clearance | 3 radii clear | at the edge | 0.06 / 0.10 |

   Index = 100 × (1 − risk), where risk = 0.6 × the weighted mean + 0.4 × the single worst factor, so one bad
   factor shows even when the rest are good. A factor at 0.25 or less becomes a "safe" tag, at 0.5 or more an
   "unsafe" tag.
5. **Rank.** By index, then by distance. The preferred-trail route goes first when its index is within
   5 points of the best; otherwise it is listed in its place and a note says so.

The row under "Leave at" shows the Martian Year and Ls that the dust and the day length are taken from. It
is the Timeline's date: changing it in either place changes it in both, and the routes are worked out again.

### Preferred trail

The star beside each entry under "Saved routes and trails" (and the "Preferred trail" list in this tab) marks
one trail as preferred. The route-finder always works out a way along it and checks it like any other. If the
trail does not lead towards the destination, a note says it was not used.

### Live safety index and alarm

`MW.router.live()` works out the same index for where the walker stands now, once a second. It is the readout
"Safety index, live" (Settings > Display ticks it on or off, like any other readout): the number, a word
(low risk, some risk, high risk) and the worst factor. In the column and numbers-first layouts it also lists
every factor. The factors are the route's, read for one place and moment:

| Factor | Live meaning |
|---|---|
| Dust | the activity class of the cell the walker is in, on the Timeline's date |
| Regional slope | the slope where the walker stands |
| Climb | height above or below the nearest base |
| Base | straight-line distance to the nearest base |
| Time | time already out plus the way back, against the 8 h limit |
| Temperature | fall in air temperature from the start of the walk to the end of the way back |
| Daylight | light left on getting back to base |
| Unwalked ground | distance to the nearest known trail (Curiosity's drive or a saved trail); 300 m is full risk |
| Hazard | distance to the edge of the nearest danger marker, or being inside a hazard area |

The **safety alarm** (Settings > Display: on or off, with or without sound, and the index limit: 40, 50, 60
or 70; 50 at first) shows a red banner on the map and gives three short beeps when:

- the index is below the limit;
- one factor reaches a risk of 0.8 (for example, inside a danger marker's keep-clear distance);
- the index has fallen 15 points, or one factor's risk has risen by 0.3, within ten minutes of the walk.

Each cause rings once and again only after it has cleared and come back. "Dismiss" silences the causes on
show; a new cause still rings. Browsers allow sound only after the page has been clicked or tapped once.
The thresholds are `ROUTER.LIVE` in `config.js`. `MW.navUI.live()` returns the latest reading.

### What the terrain data is, and is not

`python terrain_ingest.py` builds the terrain pack from two files in the
[SHTOOLS example data](https://github.com/SHTOOLS/SHTOOLS/tree/master/examples/ExampleDataFiles):
**MarsTopo719** (M. Wieczorek, 2015: the shape of Mars from MGS MOLA altimetry, spherical harmonics to
degree 719) and **GMM-3** (Genova et al., 2016, NASA GSFC: the gravity field). Height is the shape minus the
areoid, the equipotential surface whose mean equatorial radius is 3,396 km (the MOLA datum). The script
checks nine landing sites against their published MOLA heights and stops if a flat one is more than 60 m out
(the eight on flat ground agree to within 27 m). From the start to the end of Curiosity's drive the model
rises 195 m; the rover's own position fixes give 175 m.

- It resolves features about 15 km across. **A cliff, a butte, a dune field or a boulder field is not in it.**
  "Regional slope" is the tilt of the land over kilometres; the flank of Mount Sharp at the boxwork reads 8.5°.
  A destination "on a cliff" is refused only when the land around it is steep at that scale (a scarp of
  Olympus Mons, a wall of Valles Marineris). Local hazards have to be marked with danger markers.
- The limits and weights are this project's planning assumptions, not NASA flight rules.
- Temperature uses Curiosity's REMS low and high with a modelled daily curve, within 150 km of base; farther
  away it is left out and a note says so. Day length follows latitude and the Timeline's season.
- A robot's time uses 4 cm/s (Curiosity's top speed) for 6 h a sol. On the map the pointer still moves at
  the walking pace set in `config.js`, whatever the walker.
- The dust class is the one for the date chosen on the Timeline. It is a past observation, not a forecast.

## Going to a place, checkpoints and sites

"Go to a place" is the first part of the Menu tab (`places-ui.js`). Type to search, or open a group:
your checkpoints, your markers, the NASA places (Gale crater, landing sites, the planet), the start and end of
each saved trail, every tenth Curiosity stop (search "sol 4700" for any of them) and, once the dust record has
been read, the place where each detected dust storm was densest.

- **View** (arrow) moves the map there and leaves the walker where it is. It works anywhere. It says which
  imagery is sharpest there (HiRISE 0.6 m, CTX 10 m, or Viking at about 232 m per pixel beyond Gale) and does not
  zoom past it. The dust monitor switches to that place. A storm also sets the Timeline to its date.
- **Walk from here** (walker) puts the walker there with a fresh trail; if a walk is under way it first offers to
  save it. Within 60 km of base (`PLACES.LOCAL_KM`) the base stays. Farther away **the base moves too**: that place
  becomes a new site, because local metres east and north of base are only accurate near base (to well under 1 %
  within 60 km). At a new site, distances, the route-finder, the live safety index and the walk budget count from
  the new base, height and slope come from the regional terrain model, and the weather readings and rover photos
  (which are Curiosity's, at Gale) show "–". Any Gale place takes the walker back to the Gale base. A saved trail
  remembers its site, and replaying it goes back there.
- **Checkpoints** save the map view or the walker's position under a name (star and pin buttons). They are kept
  in the browser (`marswalk.checkpoints.v1`) and can be downloaded and imported as `marswalk-checkpoints.json`.
- **View links.** The address bar always holds the view, `#map=lat,lon,zoom&dust=MY,Ls`; the globe button copies
  it. Opening such a link shows the same place and the same dust date.

## Pictures of places

The panel at the top right of the map (`imagery.js`) shows the best real NASA picture of where the walker stands, and
follows the walker as it moves; "View from here" brings it back after it is closed.

- **On Curiosity's drive** (within 60 m of one of its 120 stops): a photo from the rover's left Navigation Camera taken
  at that stop. Online, the app asks NASA's raw-image service (`mars.nasa.gov/api/v1/raw_image_items`) for the Navcam
  frames of that sol and picks one taken where the sol's drive ended, looking out rather than down at the deck, and
  facing the walker's heading. The caption gives the image id, the capture time in UTC and the sol. If the service
  cannot be reached, the frame stored with the route (`data.js`) is shown, and its date is labelled as worked out from
  the sol.
- **Anywhere else**: a view from orbit cut from the same NASA Mars Trek mosaics the map uses (HiRISE at Gale's centre,
  CTX around it, the Viking colour mosaic elsewhere), centred on the spot with a cross, with its width in metres or km.
  The caption names the mosaic and its layer, and says what is known of the dates: Viking images were taken 1976 to
  1980; HiRISE and CTX images from 2006 on, the date of each image in a mosaic varying.
- **Nothing to show** (no connection and nothing kept offline): "No imagery available for this location." It never
  shows a picture of somewhere else.

The pictures come from NASA servers and need an internet connection the first time. Served from a web address, the
offline store keeps the rover photos and image lists you have seen, and the map tiles the orbital view is cut from.

## Walk budget

Three readouts (`budget.js`, assumptions in `BUDGET` in `config.js`), all **modelled**:

- **Oxygen left**: metabolism from pace and climb (150 W standing, 125 W more per m/s, climbing at 20 %
  efficiency for 200 kg of person and suit), 1 litre of O2 per 20.1 kJ, 0.70 kg carried. Steady walking lasts
  about 9 hours.
- **Battery left**: 80 W for the suit's systems, plus heaters below −20 °C (1 W per degree colder), from 1.2 kWh.
  A **robot** is a solar rover the size of Spirit or Opportunity: it draws 50 W standing and 120 W driving, and its
  1.3 m² of panels recharge it by day, with the sunlight dimmed by the dust observed on the Timeline's date
  (in MY34's global storm the direct sun all but disappears, as it did for Opportunity).
- **Turn back in**: how long you can keep walking out before the oxygen or battery left, less a 15 % reserve,
  only just covers the walk back to the nearest base (straight line × 1.25 at walking pace). Under 15 minutes it
  turns orange and a notice appears on the map; at zero it says "Turn back now". A robot need not come back.

Route cards in Markers and routes show the oxygen and battery an astronaut would have left on getting back.
These are planning assumptions, not suit specifications.

**Your own oxygen model** (Settings > Walk budget: oxygen model, `o2-model.js`). Two kinds: **From effort** (the
default kind: standing metabolism, extra per m/s walked, person-and-suit mass and muscle efficiency for climbing, and
the energy per litre of oxygen) or **Fixed rates** (kg/h walking and kg/h standing, as a suit datasheet might quote
them); both take the oxygen carried (kg) and the reserve (%). Each field shows its unit and range and is checked
before saving; a blank field takes the default shown in it. Nothing changes until **Save my model**, after which the
oxygen readouts, the status symbol and route cards say "your oxygen model". **Use the defaults** removes it; the
defaults in `BUDGET` are never changed. A model can be downloaded and imported as a `.marswalk-o2.json` file, and is
kept with the other settings (`marswalk.settings.v1`, `o2Model`).

## Walking together

"Walk together" in the Menu tab (`companions.js`) puts the other walkers on the map with yours: yellow
arrows for astronauts, green for robots, with their names. Each can stand still, replay Curiosity's drive or a
saved trail beside you (it moves while Start is pressed, at the same pace and speed-up), or follow real position
fixes: `Marswalk.setPose({ walker: 'w2', lat, lon, heading })`. The list says where each is from you.

## Best season for a walk here

In the Dust Storm tab (`season.js`), for the place the dust monitor describes: the median and 90th percentile
of the observed dust through the Martian year over every year in the record, how often each season had HIGH or
SEVERE dust, the clearest 60° of Ls and the next Earth dates it comes round (Ls is turned into a date with the
newest year's calendar, so the dates are approximate). At Gale the clearest season is Ls 45°–105°; the next one
runs from about January to May 2027. It is a record of past years, not a forecast.

## Offline map

`sw.js` is a service worker, registered by `offline.js` when the page is served from localhost or https:

- the app's own files are kept when it installs, and fetched from the network first afterwards (so changes
  show at once) with the kept copy as the fallback;
- every NASA tile you look at is kept (up to 20,000, oldest dropped first) and served from the store;
- **Save the walk area** (Map Overlay tab) shows how many tiles and roughly how many MB it will fetch, then
  saves the photo map around the walk: HiRISE at full detail within 2.5 km, coarser zooms farther out, the whole
  planet at low zoom, and the overlay that is switched on (`OFFLINE` in `config.js`). At Gale that is about
  3,600 tiles. **Delete kept tiles** empties the store.

The dust packs (7 MB) are loaded by `lazy.js` after the map's first view rather than with the page, so on a
slow link the map comes first. `build.py` turns them back into ordinary scripts in `marswalk.html`.
They are not split by year: the precomputed baselines, the live safety index, the season planner and the storm
list all need the whole record soon after start, so loading one year at a time would not save the download.

## Testing

```
node dust_test.js        the dust detection against the real data
node router_test.js      the terrain pack and the route-finder
node features_test.js    walk budget, places, sites, slope along the drive, season planner
node page_test.js        the real page in headless Chrome or Edge, offline included
```

(In this flat checkout leave out ``.) `page_test.js` needs Node 22 or later and Chrome or Edge; set
`CHROME=/path/to/browser` to choose one. It needs an internet connection for the map tiles.

## Coordinates

Planetocentric latitude and east longitude, as the NASA tiles use (Leaflet `L.CRS.EPSG4326`).
Local x and y are metres east and north of base on a sphere of radius 3,396,190 m.
Height is metres relative to the MOLA geoid. Heading is degrees clockwise from north.

## Known gaps

- No CRISM mineral map, HiRISE terrain model, local slope map or geologic-unit lookup. Trek does not
  serve these as tiles for this site; they need downloading from PDS/USGS and tiling. Until then the
  route-finder's slope is regional (about 15 km): see "What the terrain data is, and is not".
- The map needs NASA's servers the first time; offline use needs the page served from a web address and the
  walk area saved first (see "Offline map"). A file opened by double-click cannot keep anything.
- The walk budget is a model with assumed suit and rover sizes, not a reading from equipment. There is no
  position-uncertainty ring. The route-finder still uses its 8 h limit for the outing; the budget is shown beside it.
- Markers stay in one browser: there is no marker export or import yet.
- Companions replay routes or follow fixes; they do not find their own way, and they are not saved between visits.
- Away from Gale there is no weather and no rover photo, and height and slope are regional (about 15 km).
  Slope along the drive is local only on Curiosity's route.
- Landmark outlines are approximations (see Landmarks); proper outlines need the USGS geologic map.
- REMS weather ends at sol 4995 in the public feed; later stops reuse that sol.
- Saved trails stay in one browser unless downloaded.
- With the map first on a wide screen, part of the map lies under the panels. Popups, routes and places keep
  clear of them, but the walk-scale view centres the walker on the whole window, slightly left of the open
  part's centre when both panels are open. Fold either panel for more map.
- Dust: an archive ending in MY36, at 6° × 5°; see "Dust storm activity, What it is not".

## Credits

Imagery and data: NASA/JPL-Caltech, USGS, University of Arizona, MSSS, ASU, ESA/DLR/FU Berlin (HRSC).
Dust optical depth: L. Montabone, F. Forget, E. Millour and co-authors, LMD/Space Science Institute, from NASA MGS TES,
Mars Odyssey THEMIS and MRO MCS retrievals (CC BY-SA 3.0; averaged and quantised here, and shared under the same licence).
Terrain: MarsTopo719 shape model by M. A. Wieczorek (2015), from NASA MGS MOLA; GMM-3 gravity field by
A. Genova and co-authors (2016), NASA GSFC; both as distributed with the SHTOOLS project.
Map library: Leaflet 1.9.4 (BSD-2-Clause). NASA does not endorse this project.
